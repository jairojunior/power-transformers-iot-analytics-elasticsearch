from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
from crhelper import CfnResource

import boto3
import json
import os

helper = CfnResource()

@helper.create
@helper.update
def load_dashboards():
    host = os.environ('ES_HOST')
    region = os.environ('ES_REGION')

    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service,
                       session_token=credentials.token)

    es = Elasticsearch(
        hosts=[{'host': host, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )

    with open('kibana.json') as data_file:
        data = json.load(data_file)
    es.create(index='.kibana', id='power_transformer_dashboard', body=data)
@helper.delete
def no_op(_, __):
    pass


def handler(event, context):
    helper(event, context)
