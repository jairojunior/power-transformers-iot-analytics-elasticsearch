from elasticsearch import Elasticsearch, RequestsHttpConnection
from elasticsearch.helpers import bulk
from requests_aws4auth import AWS4Auth
import boto3
import logging
import sys
import csv
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)
streamHandler = logging.StreamHandler(stream=sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
streamHandler.setFormatter(formatter)
logger.addHandler(streamHandler)

host = os.environ('ES_HOST')
region = os.environ('ES_REGION')

service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

es = Elasticsearch(
    hosts = [{'host': host, 'port': 443}],
    http_auth = awsauth,
    use_ssl = True,
    verify_certs = True,
    connection_class = RequestsHttpConnection
)

s3 = boto3.client('s3')

def csv_data(lines):
    for row in csv.reader(lines):
        yield {
              oiltemperatureoilleveltemperaturehumiditynoiselevelgasemissionlevelmoistureleveltimestampid_id_monthsofusagelatlon__dt
            "_type": 'doc',
            "oilTemperature": row[0], 
            "oilLevel": row[1], 
            "temperature": row[2], 
            "humidity": row[3], 
            "noiseLevel": row[4],
            "gasEmissionLevel": row[5], 
            "moistureLevel": row[6], 
            "timestamp": row[7],
            "name": row[8],
            "location": { 'lat': row[11], 'lon': row[12] }
        }
        
        
def predict_ttf(row):
    sm = boto3.client('sagemaker-runtime')
    endpoint_name = "predict-ttf-pt"
    content_type = "text/csv"
    accept = "text/csv"
    
    response = sm.invoke_endpoint(
        EndpointName=endpoint_name, 
        ContentType=content_type,
        Accept=accept,
        Body=row)
    
    return float(response['Body'].read())

def csv_daily_data(lines):
    for row in csv.reader(lines):
        if len(row[3]) > 0:
          next

        # oilTemperature,oilLevel,moistureLevel,noiseLevel,gasEmissionLevel,monthsOfUsage
        ttf = predict_ttf("%s,%s,%s,%s,%s,%s" % (row[4], row[5], row[6], row[7], row[8], row[3]))

        yield {
            "_type": 'doc',
            "name": row[0],
            "location": { 'lat': row[1], 'lon': row[2] },
            "monthsOfUsage": row[3],
            "oilTemperature": row[4], 
            "oilLevel": row[5], 
            "moistureLevel": row[6], 
            "noiseLevel": row[7],
            "gasEmissionLevel": row[8],
            "ttf": ttf
        }

def handler(event, context):
    logger.info("event before processing: {}".format(event))
    
    for record in event['Records']:

        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        obj = s3.get_object(Bucket=bucket, Key=key)
        body = obj['Body'].read()
        lines = body.decode("utf-8").splitlines()
        
        logger.info("number of entries to send to ES: {}".format(len(lines)))
        
        if key.startswith('power_transformer_telemetry_dataset'):
            bulk(es, csv_data(lines[1:]), index='power-transformer')
            
        if key.startswith('power_transformer_daily_avg'):
            bulk(es, csv_daily_data(lines[1:]), index='daily-power-transformer')